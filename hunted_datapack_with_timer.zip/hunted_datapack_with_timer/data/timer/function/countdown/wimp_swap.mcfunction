execute as @a[scores={Class=7},limit=1,sort=nearest] at @s run summon minecraft:marker ~ ~ ~ {Tags:["swap_wimp_loc"]}
execute as @a[team=Killers,limit=1,sort=nearest,distance=..10] at @s run summon minecraft:marker ~ ~ ~ {Tags:["swap_killer_loc"]}
execute as @a[team=Killers,limit=1,sort=nearest] at @s run tp @s @e[type=minecraft:marker,tag=swap_wimp_loc,limit=1,sort=nearest]
execute as @a[scores={Class=7},limit=1,sort=nearest] at @s run tp @s @e[type=minecraft:marker,tag=swap_killer_loc,limit=1,sort=nearest]
kill @e[type=minecraft:marker,tag=swap_wimp_loc]
kill @e[type=minecraft:marker,tag=swap_killer_loc]