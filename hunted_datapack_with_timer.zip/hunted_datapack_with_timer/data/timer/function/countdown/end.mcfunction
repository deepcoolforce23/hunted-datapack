# End the countdown at 0
scoreboard players set #game play 0
scoreboard players set countdown_st runtime 0
bossbar set 1 visible false
gamemode survival @a

title @a title {"text":"Game End","bold":true,"color":"dark_red"}
tellraw @a {"text":"Game has ended","bold":true,"italic":true,"color":"dark_red"}
tp @a -171 -18 68
scoreboard players set @a Class 0
clear @a
effect clear @a
execute as @a run attribute @s max_health base set 20
team leave @a
tag @a remove picked
function timer:countdown/reset

