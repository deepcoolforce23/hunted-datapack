# Handle players who have died by putting them in spectator mode
execute as @a[scores={dead=1..},gamemode=!spectator] run gamemode spectator @s
execute as @a[scores={dead=1..},gamemode=spectator,team=Survivors] run team leave @s
execute as @a[scores={dead=1..},gamemode=spectator,team=Killers] run team leave @s
execute as @a[scores={dead=1..}] run scoreboard players set @s dead 0