function timer:handle_deaths
function timer:check_survivors
function timer:speedrun/color1
