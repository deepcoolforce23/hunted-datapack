# End the game when no survivors remain alive
execute unless entity @a[team=Survivors,gamemode=!spectator] run function timer:countdown/end
