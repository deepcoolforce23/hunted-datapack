tellraw @a {"text":"-----------------","bold":true}
tellraw @a ["",{"text":"Rainbow: ","bold":true,"italic":true},"[",{"text":"off","bold":true,"italic":true,"color":"dark_red","click_event":{"action":"run_command","command":"/trigger timer_trigger set 52"}},"]"]
tellraw @a {"text":" ","bold":true}
tellraw @a ["","[",{"text":"R1","bold":true,"italic":true,"color":"light_purple","click_event":{"action":"run_command","command":"/trigger timer_trigger set 53"}},"]"]
tellraw @a ["","[",{"text":"R2","bold":true,"italic":true,"color":"light_purple","click_event":{"action":"run_command","command":"/trigger timer_trigger set 54"}},"]"]
tellraw @a {"text":"-----------------","bold":true}
