tellraw @a {"text":"-----------------","bold":true}
tellraw @a ["",{"text":"["},{"text":"Settings","bold":true,"color":"dark_aqua","click_event":{action:"run_command","command":"/trigger timer_trigger set 6"}},{"text":"]"}]
tellraw @a ["","[",{"text":"Color Settings","bold":true,"color":"blue","click_event":{action:"run_command","command":"/trigger timer_trigger set 23"}},"]"]
tellraw @a ["","[",{"text":"Countdown","bold":true,"color":"gray","click_event":{action:"run_command","command":"/trigger timer_trigger set 25"}},{"text":"]"}]
tellraw @p ["",{"text":"["},{"text":"Help","bold":true,"italic":true,"color":"yellow","click_event":{action:"run_command","command":"/trigger timer_trigger set 47"}},{"text":"]"}]
tellraw @a {"text":"-----------------","bold":true}
