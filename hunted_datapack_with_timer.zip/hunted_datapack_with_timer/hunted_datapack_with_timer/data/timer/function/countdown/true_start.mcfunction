execute as @r run team join Killers @s
tp @a[team=Killers] -163 -59 127
execute as @a[team=Killers] run function timer:countdown/killer_select
execute as @a[team=None] run function timer:countdown/survivor_select
title @a title "GAME STARTS IN 30S"
schedule function timer:countdown/start 30s replace