# Confirmation Message that 10s was added

scoreboard players add cd_s runtime 10
scoreboard players add cd_sc runtime 10
tellraw @a {"text":"added 10s","bold":true,"italic":true,"color":"dark_green"}

function timer:countdown/secure/secure_adding
