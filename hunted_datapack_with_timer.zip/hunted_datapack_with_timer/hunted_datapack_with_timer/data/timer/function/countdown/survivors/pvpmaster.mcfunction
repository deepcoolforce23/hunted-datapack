execute as @s[scores={Class=0},team=None,tag=!picked] run scoreboard players set @s Class 1
execute as @s[scores={Class=1}] run item replace entity @s hotbar.0 with minecraft:mace[enchantments={"wind_burst":1,"enchantencore:weakness_aspect":5,"enchantencore:slowness_aspect":4}]
execute as @s[scores={Class=1}] run give @s minecraft:wind_charge
execute as @s[scores={Class=1}] run give @s minecraft:golden_apple
execute as @s[scores={Class=1}] run give @s minecraft:diamond_boots[enchantments={"minecraft:feather_falling":3}]
function timer:countdown/survivors/survivor_help