execute if entity @s[scores={Class=0},team=None,tag=!picked] run scoreboard players set @s Class 5
execute if entity @s[scores={Class=5}] run give @s minecraft:crossbow[minecraft:item_name='Gun',minecraft:custom_model_data={strings:["gun"]},lore=['{"text":"Slows killer for 1 second","color":"red"}']]
execute if entity @s[scores={Class=5}] run give @s minecraft:trial_key[minecraft:item_name='Bypass Key']
execute if entity @s[scores={Class=5}] run item replace entity @s armor.head with minecraft:leather_helmet[enchantments={"enchantencore:illumination":2,unbreaking:3},minecraft:custom_name="Illumination Goggles"]
function timer:countdown/survivors/survivor_help