execute if entity @s[scores={Class=0},team=None,tag=!picked] run scoreboard players set @s Class 8
execute if entity @s[scores={Class=8},team=None,tag=!picked] run give @s minecraft:gold_nugget[minecraft:item_name='Coin']
function timer:countdown/survivors/survivor_help