scoreboard players set @s[scores={Class=0},team=None,tag=!picked] Class 6
execute as @s[scores={Class=6}] run item replace entity @s hotbar.0 with minecraft:iron_sword[custom_model_data={strings:["bat"]},enchantments={"enchantencore:slowness_aspect":5,"enchantencore:weakness_aspect":5},custom_name="Old Bat",minecraft:enchantment_glint_override=false]
execute as @s[scores={Class=6}] run give @s minecraft:potion[minecraft:custom_name="Medicine",potion_contents=regeneration]
execute as @s[scores={Class=6}] run effect give @s minecraft:mining_fatigue infinite 8 true
function timer:countdown/survivors/survivor_help