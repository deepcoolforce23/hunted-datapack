execute if entity @s[scores={Class=0},team=None,tag=!picked] run scoreboard players set @s Class 4
function timer:countdown/survivors/survivor_help