execute as @s[scores={Class=0},team=None,tag=!picked] run scoreboard players set @s Class 7
execute as @s[scores={Class=7}] run give @s snowball[minecraft:item_name='Smoke Grenade']
execute as @s[scores={Class=7}] run attribute @s minecraft:max_health base set 10
execute as @s[scores={Class=7}] run give @s minecraft:lantern[minecraft:item_name='Divert']
execute as @s[scores={Class=7}] run give @s minecraft:leather_boots[enchantments={"enchantencore:invisibility_cloak":1,unbreaking:3},minecraft:custom_name="Invis Boots"]
function timer:countdown/survivors/survivor_help