gamemode survival @a
weather thunder
time set midnight
effect give @a[scores={Class=10..100},] minecraft:regeneration 10 200 true
tag @a[team=Killers] add ENRAGED
effect give @a minecraft:saturation 2 100
effect give @a[scores={Class=10..20}] minecraft:health_boost infinite 200 true
clone -117 -60 84 -117 -60 84 -105 -59 115
setblock -92 -61 115 air
clone -119 -60 84 -119 -60 84 -113 -56 142
clone -120 -60 85 -120 -60 85 -85 -59 116
setblock -108 -61 138 minecraft:redstone_torch
setblock -101 -61 128 air
clone -123 -60 84 -123 -60 84 -88 -59 131
setblock -124 -61 111 air
clone -125 -60 84 -125 -60 84 -108 -62 88
fill -61 -59 102 -64 -57 99 minecraft:pale_oak_leaves
setblock -108 -63 90 stone_bricks
tp @a[team=Survivors] -104 -59 116
tp @a[team=Killers] -73 -59 120
function timer:countdown/maps/banner