title @a[team=Survivors] title {"text":"RUN OR HIDE","color":"red","bold":true}
title @a[team=Survivors] title {"text":"KILL EVERYONE","color":"red","bold":true}