tp @a[team=Survivors] -89 -30 39
tp @a[team=Killers] -71 -30 16
setblock -28 -29 40 air replace
function timer:countdown/maps/banner