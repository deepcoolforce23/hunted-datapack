title @a title {"text":"IT SPREADS.","color":"aqua","bold":true,"italic":true}
title @a[scores={Class=30}] actionbar {"text":"you feel an entanglement in your SOUL...","color":"aqua","italic":true}
gamemode survival @a
tp @a[team=Survivors] -119 -59 256
tp @a[team=Killers] -140 -55 211
effect give @a minecraft:regeneration 10 255 true
function timer:countdown/maps/banner
