tellraw @s {color:"red","bold":true,"text":"You have been ABANDONED.\nChoose the vessel of your wrath.\n--------------------------------"}
tellraw @s {"click_event":{"action":"run_command","command":"/trigger timer_trigger set 71"},"color":"dark_purple","text":"[Alchemist]","bold":true,"hover_event":{"action":"show_text","value":"Utilizes splash and lingering potions."}}
tellraw @s {"click_event":{"action":"run_command","command":"/trigger timer_trigger set 72"},"color":"red","text":"[Arsonist]","bold":true,"hover_event":{"action":"show_text","value":"A DPS killer that utilizes fire."}}
tellraw @s {"click_event":{"action":"run_command","command":"/trigger timer_trigger set 73"},"color":"dark_red","text":"[Butcher]","bold":true,"hover_event":{"action":"show_text","value":"A stealth killer that utilizes invisibility."}}
tellraw @s {"click_event":{"action":"run_command","command":"/trigger timer_trigger set 74"},"color":"aqua","text":"[Sculker]","bold":true,"hover_event":{"action":"show_text","value":"A rusher-type killer. Best played blind."}}
tellraw @s {"click_event":{"action":"run_command","command":"/trigger timer_trigger set 75"},"color":"gold","text":"[Yagami]","bold":true,"hover_event":{"action":"show_text","value":"A killer driven by madness."}}
tellraw @s {"click_event":{"action":"run_command","command":"/trigger timer_trigger set 76"},"color":"dark_green","text":"[Poisoner]","bold":true,"hover_event":{"action":"show_text","value":"A DPS killer that utilizes poison and 'crafting'."}}
tellraw @s {color:"red","bold":true,"text":"--------------------------------"}
