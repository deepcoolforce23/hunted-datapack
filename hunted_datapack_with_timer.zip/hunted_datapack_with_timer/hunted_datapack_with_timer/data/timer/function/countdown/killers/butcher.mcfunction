execute as @s[scores={Class=0},team=Killers,tag=!picked] run scoreboard players set @s Class 20
give @a[scores={Class=20}] minecraft:iron_sword[minecraft:custom_name="CLEAVER",minecraft:enchantments={"enchantencore:wither_aspect":1,unbreaking:3}]
give @a[scores={Class=20}] minecraft:beef[food={nutrition: 0, saturation: 100, can_always_eat: true},use_cooldown={seconds:30s}, minecraft:item_name="FRESH MEAT",minecraft:potion_contents={custom_effects:[{id:"minecraft:invisibility",duration:600},{id:"minecraft:weakness",duration:600}]}]
function timer:countdown/killers/killer_help
tellraw @a[team=Killers] {color:"dark_red", "text":"Satisfy your hunger.", "bold":true}