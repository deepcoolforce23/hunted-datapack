execute as @s[scores={Class=0},team=Killers,tag=!picked] run scoreboard players set @s[scores={Class=0},team=Killers] Class 40
give @a[scores={Class=40}] flint_and_steel[enchantments={fire_aspect:1,sharpness:2,unbreaking:3},minecraft:custom_name="LIGHTER",custom_model_data={strings:["LIGHTER"]}]
item replace entity @a[scores={Class=40}] armor.head with minecraft:golden_helmet[trim={"pattern":"tide","material":"redstone"}]
give @a[scores={Class=40}] minecraft:fire_charge[custom_name="ARSONIST URGE"]
effect give @a[scores={Class=40}] minecraft:fire_resistance infinite
tellraw @a[team=Killers] {color:"dark_red", "text":"Burn it all down.", "bold":true}
function timer:countdown/killers/killer_help