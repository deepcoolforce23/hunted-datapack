execute as @s[scores={Class=0},team=Killers,tag=!picked] run scoreboard players set @s[team=Killers,scores={Class=0}] Class 37
title @a title {"text":"THIS WILL BE FUN!!","color":"green","bold":true}
execute as @a[team=Killers,scores={Class=37}] run item replace entity @s hotbar.7 with minecraft:rotten_flesh
item replace entity @a[scores={Class=37}] hotbar.0 with minecraft:wooden_hoe[enchantments={"enchantencore:poison_aspect":5},custom_name="Poison Scythe"]
give @a[scores={Class=37}] minecraft:skeleton_skull[minecraft:item_name='Euthanize']
playsound minecraft:entity.husk.converted_to_zombie master @a ~ ~ ~ 1 0.5
playsound minecraft:entity.slime.jump master @a ~ ~ ~ 0.6 0.5
playsound minecraft:entity.wither.ambient master @a ~ ~ ~ 0.4 0.8
playsound minecraft:block.beacon.activate master @a ~ ~ ~ 0.4 0.8
execute as @a[team=Killers,scores={Class=37}] run function timer:countdown/killers/poisoner_help
function timer:countdown/killers/killer_help