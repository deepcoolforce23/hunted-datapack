item replace entity @s hotbar.6 with minecraft:spider_eye
item replace entity @s hotbar.5 with minecraft:iron_nugget
item replace entity @s hotbar.4 with minecraft:bone_meal