execute as @s[scores={Class=0},team=Killers,tag=!picked] run scoreboard players set @s[scores={Class=0},team=Killers] Class 22
give @a[scores={Class=22}] minecraft:iron_sword[enchantments={"enchantencore:wither_aspect":1,unbreaking:3},minecraft:custom_name="Deadly Knife",minecraft:custom_model_data={strings:["knife"]}]
give @a[scores={Class=22}] golden_axe[minecraft:item_name="Mangle"]
give @a[scores={Class=22}] minecraft:wind_charge[minecraft:item_name="Adrenaline Boost"]
item replace entity @a[scores={Class=22}] armor.feet with minecraft:leather_boots[enchantments={"enchantencore:invisibility_cloak":1,unbreaking:3},minecraft:custom_name="Invis Boots"]
tellraw @a[team=Killers] {color:"dark_red", "text":"Between heaven and hell.", "bold":true}
function timer:countdown/killers/killer_help