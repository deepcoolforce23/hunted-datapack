execute as @s[scores={Class=0},team=Killers,tag=!picked] run scoreboard players set @s Class 30
give @a[scores={Class=30}] minecraft:iron_sword[minecraft:custom_model_data={strings:["fist"]}]
item replace entity @a[scores={Class=30}] hotbar.1 with minecraft:spyglass[minecraft:item_name=Darkness,minecraft:custom_model_data={strings:["sculked"]}]
effect give @a[team=Killers,scores={Class=30}] minecraft:mining_fatigue infinite 0 true
item replace entity @a[scores={Class=30}] armor.head with minecraft:netherite_helmet[minecraft:trim={pattern:"minecraft:silence",material:"minecraft:lapis"}]
item replace entity @a[scores={Class=30}] armor.chest with minecraft:netherite_chestplate[minecraft:trim={pattern:"minecraft:rib",material:"minecraft:lapis"}]
execute as @a[scores={Class=30}] unless data entity @s {Inventory:[{id:"minecraft:echo_shard"}]} run item replace entity @s hotbar.2 with minecraft:echo_shard[minecraft:item_name='Stalk']
tellraw @a[team=Killers] {color:"dark_red", "text":"Abomination.", "bold":true}
function timer:countdown/killers/killer_help