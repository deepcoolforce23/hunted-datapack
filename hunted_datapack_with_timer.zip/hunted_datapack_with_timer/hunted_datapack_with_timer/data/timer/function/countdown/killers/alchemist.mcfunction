execute as @s[scores={Class=0},team=Killers,tag=!picked] run scoreboard players set @s Class 10
tellraw @a[team=Killers] {color:"dark_red", "text":"Make sure it's worth it.", "bold":true}
function timer:countdown/killers/killer_help