scoreboard objectives add rand dummy
execute store result score #global rand run random value 1..3
execute if score #global rand matches 1 run function timer:countdown/maps/map1
execute if score #global rand matches 2 run function timer:countdown/maps/map2
execute if score #global rand matches 3 run function timer:countdown/maps/map3

