scoreboard players add m runtime 1
scoreboard players remove s runtime 60
scoreboard players add h runtime 1
scoreboard players remove m runtime 60
scoreboard players add d runtime 1
scoreboard players remove h runtime 24