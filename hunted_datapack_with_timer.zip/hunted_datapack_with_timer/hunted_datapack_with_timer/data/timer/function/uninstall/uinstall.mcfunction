tellraw @a {"text":"-----------------","bold":true,"color":"white"}
tellraw @a {"text":" "}
tellraw @a {"text":"Are you sure?","bold":true,"italic":true,"color":"green","click_event":{"action":"run_command","command":"/function timer:uninstall/2_unistall"}}
tellraw @a {"text":" "}
tellraw @a {"text":"-----------------","bold":true,"color":"white"}
