The stuff used in the actual game is in data/timer/function/countdown

Event killers:
sukuna

Regular killers:
Poisoner
Alchemist
Butcher
Arsonist
Sculker
Yagami

Survivors:
Coin
Druglord
Gun
Hooligan
Pvp master
Wimp

TODO: make sukuna functional (zavier this is your job)